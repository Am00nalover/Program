package sep;

import java.util.*;

/**
 *
 */
public class Event {

    private String Type;

    private String Name;

    private static String Date;//Date

    private static int startT;
    
    private static int EndT;
    
    private LinkedList<String> Location;

    private LinkedList<String> Requirement;

    public Event(String Type, String Name, String Date, int startT,int EndT, LinkedList<String> Location, LinkedList<String> Requirement) {
        this.Type = Type;
        this.Name = Name;
        this.Date = Date;
        this.startT = startT;
        this.EndT=EndT;
        this.Location = Location;
        this.Requirement = Requirement;
    }

    public String getType() {
        return Type;
    }

    public String getName() {
        return Name;
    }

    public String getDate() {
        return Date;
    }

    public int getStartT() {
        return startT;
    }

    public int getEndT() {
        return EndT;
    }

    public String getRequirement(int i) {
        return Requirement.get(i);
    }

  

    public LinkedList<String> getLocation() {
        return Location;
    }



    public void setType(String Type) {
        this.Type = Type;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setStartT(int startT) {
        this.startT = startT;
    }

    public void setEndT(int EndT) {
        this.EndT = EndT;
    }

    public void setRequirement(LinkedList<String> Requirement) {
        this.Requirement = Requirement;
    }


    public void setLocation(LinkedList<String> Location) {
        this.Location = Location;
    }

    
  public void Remainderset(Date date, String Name) {
        // TODO implement here
    }

 
    public void Remainderget( Date date, String Name) {
    }
       
    public void info() {
        if (getType().equals("Diseases")) {

        } else {
            System.out.println("This is " + getName() + " Event");
            System.out.println("Going to Hold at " + getDate());
            System.out.println("Stat at " + getStartT());
            System.out.println("End at " + getStartT());
            System.out.println("at ");
            for (int i = 0; i < Requirement.size(); i++) {
                System.out.println("You have to " + getRequirement(i));
                System.out.println("at ");
            }
        }

    }

}
