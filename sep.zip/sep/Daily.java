package sep;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 */
public class Daily {

    private String Type;

    private String Date;

    private static LinkedList<String> time = new LinkedList<String>();

    private static LinkedList<String> task = new LinkedList<String>();

    private static LinkedList<String> Location = new LinkedList<String>();

    private Patient info;
    Date de = new Date();
    date df = new date();

    Daily(String TypeD, String DateD, LinkedList<String> TimeD, LinkedList<String> taskD, LinkedList<String> LocationD) {
        this.Type = TypeD;
        this.Date = DateD;
        this.time = TimeD;
        this.task = taskD;
        this.Location = LocationD;
    }

    public String getType() {
        return Type;
    }

    public String getDate() {
        return Date;
    }

    public static String getTime(int i) {
        return time.get(i);
    }

    public static String getTask(int i) {
        return task.get(i);
    }

    public static String getLocation(int i) {
        return Location.get(i);
    }//make sure

    public Patient getInfo() {
        return info;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public static void setTime(LinkedList<String> time) {
        Daily.time = time;
    }

    public static void setTask(LinkedList<String> task) {
        Daily.task = task;
    }

    public static void setLocation(LinkedList<String> Location1) {
    }

    void info() {

        System.out.println("good morning");
        System.out.println("Hello Mr." + info.getName());
        System.out.println("Your " + info.getAge());
        System.out.println("Today is " + df.toDay(de.getDay()));
        System.out.println("The currant time is" + df.totime(de.getTime()));
        System.out.println("Here what to gonig to do today");
        for (int i = 0; i < time.size(); i++) {
            System.out.println("The time : " + getTime(i));
            System.out.println("To do: " + getTask(i));
            System.out.println("Where: " + getLocation(i));
        }

    }

}
