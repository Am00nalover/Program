package sep;

import java.util.*;

/**
 *
 */
public class Diseases {

    private String Type;

    private String Treatment[];

    private String Requirement[];
    
    private String type;

    private Event Event[];
    int num;

    public Diseases(String Type, String type, String[] Treatment, String[] Requirement,int num) {
        this.Type = Type;
        this.Treatment = Treatment;
        this.Requirement = Requirement;
        this.type = type;
        this.num=num;
    }

    Diseases(String Dtype, String type, LinkedList<String> TreatmentD, LinkedList<String> RequirementD, int count) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Diseases(String Dtype, String type, LinkedList<String> TreatmentD, LinkedList<String> RequirementD) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getType() {
        return Type;
    }

    public String getTreatment(int i) {
        return Treatment[i];
    }

    public String getRequirement(int i) {
        return Requirement[i];
    }

    public Event getEven(int i) {
        return Event[i];
    }
     public String gettype() {
        return type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public void setTreatment(String[] Treatment) {
        this.Treatment = Treatment;
    }

    public void setRequirement(String[] Requirement) {
        this.Requirement = Requirement;
    }

    public void setEven(Event[] Event) {
        this.Event = Event;
    }
    public void info(){
        
        System.out.println("This is "+getType()+" Disease\nIt is "+gettype());
        for (int i = 0; i < num; i++) {
            System.out.println("The medicine name is "+ getTreatment(i));
            System.out.println("It needs "+ getRequirement(i));
            System.out.println("the medicine is in the ");//Event requier
        }
    
    }
      

}
