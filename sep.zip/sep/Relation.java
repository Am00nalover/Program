package sep;

import java.util.*;

/**
 *
 */
public class Relation {

    public String Name;

    public int Age;

    public String relat;
    String Gender;

//    public Object Pic; must reemper 
    public String Jop;

    public int PhoneNumber;

    public String Location;

    public Relation(String Name, int Age, String relat, String Gender, String Jop, int PhoneNumber, String Location) {
        this.Name = Name;
        this.Age = Age;
        this.relat = relat;
        this.Gender = Gender;
        this.Jop = Jop;
        this.PhoneNumber = PhoneNumber;
        this.Location = Location;
    }

    public String getName() {
        return Name;
    }

    public int getAge() {
        return Age;
    }

    private String getGender() {
        return Gender;
    }

    public String getRelat() {
        return relat;
    }
//
//    public Object getPic() {
//        return Pic;
//    }

    public String getJop() {
        return Jop;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public String getLocation() {
        return Location;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public void setRelat(String relat) {
        this.relat = relat;
    }

//    public void setPic(Object Pic) {
//        this.Pic = Pic;
//    }
    public void setJop(String Jop) {
        this.Jop = Jop;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    void info() {
        System.out.println("Name: " + getName() + ". Age: " + getAge() + ". relat " + getRelat() + ". Gender: " + getGender() + ". Jop" + getJop() + ". PhoneNumber" + getPhoneNumber() + ". Location" + getLocation());
    }

}
