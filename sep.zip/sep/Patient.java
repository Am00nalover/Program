/*
we should add an option to delete R and D 
changed the date to String 
Changed th loc to String 
changed the number in relation class to in
changes the Location to String
Make relation and Daliy linked list
 */
package sep;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.Scanner;
import static sep.avi.quit;

/**
 *
 */
public class Patient {

    /**
     * Default constructor
     */
    private static String Name;

    private static int Age;

    private static String BD;

    private static String Gander;

    private static String Jop;

    private Object Pic;

    private static LinkedList<Relation> Relotion = new LinkedList<Relation>();

    private static LinkedList<Daily> Daily = new LinkedList();

    private static LinkedList<Event> Event = new LinkedList<Event>();
    
    private static LinkedList<Diseases> Diseases = new LinkedList<Diseases>();
    static Date de = new Date();
    static Calendar calendar = Calendar.getInstance(); 

    public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
        System.out.println(de);
        Scanner input = new Scanner(System.in);
        boolean flag = true;
        System.out.println("Hello there we hope that your going to help us know you more :)");
        System.out.println("What is your Name ?");
        setName(input.nextLine());
        System.out.println(getName());
        System.out.println("What is your Gander? M or F");
        do {

            switch (input.next().toUpperCase() + "") {
                case "F":
                    setGander("Female");
                    flag = false;
                    break;
                case "M":
                    setGander("Male");
                    flag = false;
                    break;
                default:
                    System.out.println("!!you should answer with M or F!!");
                    break;
            }
        } while (flag);
        System.out.println("What is your Birth Date");
        System.out.println("Year FORMAT:YYYY");
        int year = input.nextInt();
        System.out.println("Month FORMAT MM");
        int Month = input.nextInt();
        System.out.println("Day FORMAT DD");
        int day = input.nextInt();
        String t = year + "/" + Month + "/" + day;
        setBD(t);
        System.out.println("What is your Jop");
        setJop(input.next());
        while (true) {
            System.out.println("please choose your operation : \n 1 for Display Daily \n 2 for Adding a New Daily \n 3 for Display Relation \n 4 for Add new Relation \n 5 for Display Diseases \n 6 for Add new Diseases ");
            System.out.println(" 7 for Display Daily Event \n 8 Adding a New Event");
           
            switch (input.next() + "") {
                case "1":
                    System.out.println("please choose the number you want");
                    for (int i = 0; i < Daily.size(); i++) {
                        System.out.println((i + 1) + ":");
                        System.out.println(Daily.get(i).getDate());
                    }
                    int num = input.nextInt();
                    DisplayDaily(num - 1);
                    break;
                case "2":
                    setDaily();
                    break;
                case "3":
                    Displayrelation();
                    break;
                case "4":
                    setRelotion();
                    break;
                case "5":
                    DisplayDiseases();
                    break;
                case "6":
                    setDiseases();
                    break;
                case "7":
                    displayEvent();
                    break;
                case "8":
                    setEvent();
                    break;
            }
            Thread mt = new Thread(new avi());
            mt.start();

            System.out.println("press 0 THEN ENTER to chose somthing");

            while (true) {
                mt.sleep(1000);
                if (quit == 1) {
                    break;
                }
                 boolean f = false;
                 boolean f1 = false;
                 int d=0;
                if (!f) {
                  for (int i = 0; i < Event.size(); i++) {
                    f = Event.get(i).getDate().equals(calendar.get(Calendar.YEAR)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get(Calendar.DATE));
                  
                }  if (f) {
                    System.out.println("2");
                        for (int u = 0; u < Event.size(); u++) {
                           f1= Event.get(u).getStartT()==calendar.getTime().getHours();
                            if (f1&&(Event.get(u).getStartT()==d)) {
                                System.out.println("3");
                                System.out.println(Event.get(u).getName()+"is happening and it will end at "+Event.get(u).getEndT()+"it'll be at "+Event.get(u).getLocation());
                                d=Event.get(u).getStartT();
                                f = false;
                                
                            }
                           
                        }
                        }
                }
            }
        }

    }


    public static void setDaily() {
        Scanner input = new Scanner(System.in);
        LinkedList<String> TimeD = new LinkedList<String>();
        LinkedList<String> taskD = new LinkedList<String>();
        LinkedList<String> LocationD = new LinkedList<String>();
        boolean flag = true;
        boolean flag1 = true;
        System.out.println(
                "What is the Activity?");
        String TypeD = input.next();

        System.out.println(
                "What is the Date?");
        System.out.println("Year FORMAT:YYYY");
        int year = input.nextInt();
        System.out.println("Month FORMAT MM");
        int Month = input.nextInt();
        System.out.println("Day FORMAT DD");
        int day = input.nextInt();
        String D = year + "/" + Month + "/" + day;
        String DateD = D;

        System.out.println(
                "What is the time ?");
        String t = input.next();
        TimeD.add(t);

        System.out.println("What to do ?");
        taskD.add(input.next());

        System.out.println("Where ?");
        LocationD.add(input.next());

        while (flag) {
            System.out.println("do you have more task to add?");
            while (flag1) {

                String ans = input.next().toLowerCase();
                if (ans.equals("yes")) {
                    System.out.println("What is the time?");
                    TimeD.add(input.next());
                    System.out.println("What to do?");
                    taskD.add(input.next());
                    System.out.println("Where?");
                    LocationD.add(input.next());
                }
                if (ans.equals("no")) {
                    flag = false;
                    flag1 = false;

                } else {
                    System.out.println("!!you should answer with yes or no!!");
                }
            }
        }

        Daily Daily1 = new Daily(TypeD, DateD, TimeD, taskD, LocationD);
        Daily.add(Daily1);
    }

    public static void DisplayDaily(int num) throws FileNotFoundException {

        Daily.get(num).info();
    }

    /**
     *
     */
    public static void Displayrelation() throws FileNotFoundException {
        for (int i = 0; i < Relotion.size(); i++) {
            System.out.println((i + 1) + ":");
            Relotion.get(i).info();
        }
    }

    public static void setName(String Name) {
        Patient.Name = Name;
    }

    public static void setAge(int Age) {
        Patient.Age = Age;
    }

    public static void setBD(String BD) {
        Patient.BD = BD;
    }

    public static void setRelotion() {
        Scanner in = new Scanner(System.in);
        System.out.println("What is your relative Name");
        String RName = in.next();
        System.out.println("how Old is your relative");
        int RAge = in.nextInt();
        System.out.println("What is his Gender");
        String RGender = in.next();
        System.out.println("how do you Relot?");
        String relat = in.next();
        System.out.println("What is his Jop");
        String Jop = in.next();
        System.out.println("What is his Phone Number");
        int PhoneNumber = in.nextInt();
        System.out.println("Where does he Live");
        String Location = in.next();
        Relation Relation1 = new Relation(RName, RAge, RGender, relat, Jop, PhoneNumber, Location);
        Relotion.add(Relation1);
    }

    public static void setDiseases() {
        Scanner input = new Scanner(System.in);
        LinkedList<String> TreatmentD = new LinkedList<String>();

        LinkedList<String> RequirementD = new LinkedList<String>();

        boolean flag1 = true;
        boolean flag = true;
        System.out.println("What kind of Diseases?");
        String Dtype = input.next();
        System.out.println("Is it chronic or acute disease?");//** chronic دائم
        String type = input.next();
        System.out.println("What is the name of the medicine?");
        TreatmentD.add(input.next());
        System.out.println("dose it have a Requiremen?");
        RequirementD.add(input.next());
        setEventD(Dtype);
        while (flag) {
            System.out.println("do you have more Treatments to add?");
            while (flag1) {
                String ans = input.next().toLowerCase();
                if (ans.equals("yes")) {
                    System.out.println("What is the name of the medicine?");
                    TreatmentD.add(input.next());
                    setEventD(Dtype);
                }
                if (ans.equals("no")) {
                    flag = false;
                    flag1 = false;

                } else {
                    System.out.println("!!you should answer with yes or no!!");
                }
            }
        }
        Diseases Diseases1 = new Diseases(Dtype, type, TreatmentD, RequirementD);
        Diseases.add(Diseases1);

    }

    public static void setEventD(String n) {//Location
        Scanner input = new Scanner(System.in);
        LinkedList<String> RequirementE = new LinkedList<String>();
        LinkedList<String> LocationD = new LinkedList<String>();
        boolean flag1 = true;
        boolean flag = true;
        System.out.println("What is the date?");
        System.out.println("Year FORMAT:YYYY");
        int year = input.nextInt();
        System.out.println("Month FORMAT MM");
        int Month = input.nextInt();
        System.out.println("Day FORMAT DD");
        int day = input.nextInt();
        String t = year + "/" + Month + "/" + day;
        String date = t;
        System.out.println("Start at?  24H");
        int start = input.nextInt();
        System.out.println("End at?  24H");
        int end = input.nextInt();
        System.out.println("Where ?");
        LocationD.add(input.next());
        System.out.println("dose it have a Requiremen?");
        RequirementE.add(input.next());

        while (flag) {
            System.out.println("do you have more Requiremen to add?");
            while (flag1) {
                String ans = input.next().toLowerCase();
                if (ans.equals("yes")) {
                    System.out.println("dose it have a Requiremen?");
                    RequirementE.add(input.next());;
                }
                if (ans.equals("no")) {
                    flag = false;
                    flag1 = false;

                } else {
                    System.out.println("!!you should answer with yes or no!!");
                }
            }
        }
        Event event = new Event("Diseases", n, date, start, end, LocationD, RequirementE);
        Event.add(event);

    }

    public static void setEvent() {//Location
        Scanner input = new Scanner(System.in);
        LinkedList<String> RequirementE = new LinkedList<String>();
        LinkedList<String> LocationD = new LinkedList<String>();
        boolean flag1 = true;

        boolean flag = true;
        System.out.println("What kind of Event?");
        String type = input.next();
        System.out.println("What is the event?");
        String Name = input.next();
        System.out.println("What is the date?");
        System.out.println("Year FORMAT:YYYY");
        int year = input.nextInt();
        System.out.println("Month FORMAT MM");
        int Month = input.nextInt();
        System.out.println("Day FORMAT DD");
        int day = input.nextInt();
        String t = year + "/" + Month + "/" + day;
        String date = t;
        System.out.println("Start at:  24H");
        int start = input.nextInt();
        System.out.println("End at:  24H");
        int end = input.nextInt();
        System.out.println("Where ?");
        LocationD.add(input.next());
        System.out.println("dose it have a Requiremen?");
        RequirementE.add(input.next());
        while (flag) {
            System.out.println("do you have more Requiremen to add?");
            while (flag1) {
                String ans = input.next().toLowerCase();
                if (ans.equals("yes")) {
                    System.out.println("dose it have a Requiremen?");
                    RequirementE.add(input.next());;
                }
                if (ans.equals("no")) {
                    flag = false;
                    flag1 = false;

                } else {
                    System.out.println("!!you should answer with yes or no!!");
                }
            }
        }
        Event event = new Event(type, Name, date, start, end, LocationD, RequirementE);
        Event.add(event);

    }

    public static void displayEvent() {
        for (int i = 0; i < Event.size(); i++) {
            Event.get(i).info();
        }
    }

    public static void DisplayDiseases() {
        for (int i = 0; i < Diseases.size(); i++) {
            Diseases.get(i).info();
        }

    }

    public static void setGander(String Gander) {
        Patient.Gander = Gander;
    }

    public static void setJop(String Jop) {
        Patient.Jop = Jop;

    }

    public void setPic(Object Pic) {

        this.Pic = Pic;
    }

    public static String getName() {
        return Name;
    }

    public static int getAge() {
        return Age;
    }

    public String getBD() {
        return BD;
    }

    public static String getGander() {
        return Gander;
    }

    public static String getJop() {
        return Jop;
    }

    public Object getPic() {
        return Pic;
    }

    public static LinkedList<Event> getEvent() {
        return Event;
    }

}

class avi implements Runnable {

    static int quit = 0;
    Scanner sc = new Scanner(System.in);

    @Override
    public void run() {
        String msg = "";
        while (!(msg.equals("0"))) {
            try {
                msg = sc.nextLine();
            } catch (Exception e) {
            }
        }
        quit = 1;
    }
}
