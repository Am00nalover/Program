/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sep;

/**
 *
 * @author amnahaltassan
 */
public class date {

    public date() {
    }



    public String toDay(int thed) {
        String d = "";
        switch (thed) {
            case 0:
                d = "Sunday";
                break;
            case 1:
                d = "Monday";
                break;
            case 2:
                d = "Tuesday";
                break;
            case 3:
                d = "Wednesday";
                break;
            case 4:
                d = "Thursday";
                break;
            case 5:
                d = "Friday";
                break;
            case 6:
                d = "Saturday";
                break;
        }
        return d;
    }

    public int fromDay(String thed) {
        int d = 0;
        switch (thed) {
            case "Sunday":
                d = 0;
                break;
            case "Monday":
                d = 1;
                break;
            case "Tuesday":
                d = 2;
                break;
            case "Wednesday":
                d = 3;
                break;
            case "Thursday":
                d = 4;
                break;
            case "Friday":
                d = 5;
                break;
            case "Saturday":
                d = 6;
                break;
        }
        return d;
    }
    
    public String totime(long milliseconds) {
        String d = "";
int minutes = (int) ((milliseconds / (1000*60)) % 60);
int hours   = (int) ((milliseconds / (1000*60*60)) % 24);
d=hours+":"+minutes;
        return d;
    }

    public int fromtime(String t) {
        int d = 0;
       String g []= t.split(":");
        for (int i = 0; i < 10; i++) {
            
        }
        return d;
    }
}
